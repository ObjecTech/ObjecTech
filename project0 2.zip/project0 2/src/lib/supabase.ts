import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string;
          company_name: string;
          role: string;
          avatar_url: string | null;
          preferences: {
            email_high_severity: boolean;
            email_weekly_summary: boolean;
            email_security_alerts: boolean;
            theme: string;
          };
          onboarding_completed: boolean;
          created_at: string;
          last_login: string | null;
        };
        Insert: {
          id: string;
          full_name: string;
          company_name: string;
          role: string;
          avatar_url?: string | null;
          preferences?: {
            email_high_severity: boolean;
            email_weekly_summary: boolean;
            email_security_alerts: boolean;
            theme: string;
          };
          onboarding_completed?: boolean;
          created_at?: string;
          last_login?: string | null;
        };
        Update: {
          id?: string;
          full_name?: string;
          company_name?: string;
          role?: string;
          avatar_url?: string | null;
          preferences?: {
            email_high_severity?: boolean;
            email_weekly_summary?: boolean;
            email_security_alerts?: boolean;
            theme?: string;
          };
          onboarding_completed?: boolean;
          created_at?: string;
          last_login?: string | null;
        };
      };
      anomaly_types: {
        Row: {
          id: string;
          category_name: string;
          description: string;
          severity_level: string;
          icon_name: string;
          color_code: string;
          created_at: string;
        };
      };
      detections: {
        Row: {
          id: string;
          user_id: string;
          image_url: string;
          keywords: string[];
          detection_results: any;
          anomaly_score: number;
          severity_level: string;
          flagged: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          image_url: string;
          keywords: string[];
          detection_results?: any;
          anomaly_score?: number;
          severity_level?: string;
          flagged?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          image_url?: string;
          keywords?: string[];
          detection_results?: any;
          anomaly_score?: number;
          severity_level?: string;
          flagged?: boolean;
          created_at?: string;
        };
      };
      detection_statistics: {
        Row: {
          id: string;
          user_id: string;
          date: string;
          total_detections: number;
          anomaly_counts: any;
          average_score: number;
          created_at: string;
        };
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          type: string;
          title: string;
          message: string;
          read: boolean;
          created_at: string;
        };
        Update: {
          read?: boolean;
        };
      };
    };
  };
};
