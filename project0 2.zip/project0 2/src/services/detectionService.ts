export interface DetectedAnomaly {
  type: string;
  confidence: number;
  boundingBox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
}

export interface DetectionResult {
  anomalyScore: number;
  detectedAnomalies: DetectedAnomaly[];
  processedImageUrl: string;
}

const anomalyTypes = [
  { type: 'Equipment Malfunction', severities: ['medium', 'high', 'critical'] },
  { type: 'Product Quality Defect', severities: ['medium', 'high'] },
  { type: 'Safety Violation', severities: ['high', 'critical'] },
  { type: 'Assembly Line Issue', severities: ['low', 'medium'] },
  { type: 'Inventory Error', severities: ['low', 'medium'] },
  { type: 'Environmental Hazard', severities: ['high', 'critical'] },
  { type: 'Gauge Anomaly', severities: ['medium', 'high'] },
  { type: 'Robotic Issue', severities: ['medium', 'high'] },
  { type: 'Conveyor Problem', severities: ['medium', 'high'] },
  { type: 'General Anomaly', severities: ['low', 'medium'] },
];

const descriptions = {
  'Equipment Malfunction': [
    'Machine showing signs of wear',
    'Tool positioning error detected',
    'Motor vibration abnormal',
    'Belt tension issue detected',
  ],
  'Product Quality Defect': [
    'Surface scratch detected',
    'Product deformation identified',
    'Color inconsistency found',
    'Dimensional error detected',
  ],
  'Safety Violation': [
    'Missing hard hat detected',
    'Unsafe zone breach identified',
    'PPE compliance issue',
    'Emergency exit blocked',
  ],
  'Assembly Line Issue': [
    'Component misalignment',
    'Spacing irregularity',
    'Timing issue detected',
    'Flow disruption identified',
  ],
  'Inventory Error': [
    'Item misplaced',
    'Quantity discrepancy',
    'Wrong bin location',
    'Missing label detected',
  ],
  'Environmental Hazard': [
    'Liquid spill detected',
    'Gas leak indicator',
    'Temperature anomaly',
    'Smoke detected',
  ],
  'Gauge Anomaly': [
    'Pressure reading abnormal',
    'Temperature out of range',
    'Flow rate irregular',
    'Gauge display error',
  ],
  'Robotic Issue': [
    'Arm positioning error',
    'Gripper malfunction',
    'Path deviation detected',
    'Speed inconsistency',
  ],
  'Conveyor Problem': [
    'Belt misalignment',
    'Speed variation detected',
    'Blockage identified',
    'Tracking issue',
  ],
  'General Anomaly': [
    'Unexpected object detected',
    'Pattern deviation',
    'Irregular behavior observed',
    'Unclassified issue',
  ],
};

const getRandomElement = <T,>(arr: T[]): T => {
  return arr[Math.floor(Math.random() * arr.length)];
};

const generateBoundingBox = () => ({
  x: Math.floor(Math.random() * 60) + 10,
  y: Math.floor(Math.random() * 60) + 10,
  width: Math.floor(Math.random() * 20) + 15,
  height: Math.floor(Math.random() * 20) + 15,
});

export const runDetection = async (
  imageUrl: string,
  keywords: string[]
): Promise<DetectionResult> => {
  await new Promise((resolve) => setTimeout(resolve, 2500));

  const numAnomalies = Math.floor(Math.random() * 4) + 1;
  const detectedAnomalies: DetectedAnomaly[] = [];

  for (let i = 0; i < numAnomalies; i++) {
    const anomalyType = getRandomElement(anomalyTypes);
    const severity = getRandomElement(anomalyType.severities) as 'low' | 'medium' | 'high' | 'critical';
    const descriptionList = descriptions[anomalyType.type as keyof typeof descriptions];

    detectedAnomalies.push({
      type: anomalyType.type,
      confidence: Math.floor(Math.random() * 25) + 70,
      boundingBox: generateBoundingBox(),
      severity,
      description: getRandomElement(descriptionList),
    });
  }

  const severityWeights = {
    low: 15,
    medium: 40,
    high: 70,
    critical: 95,
  };

  const avgSeverity =
    detectedAnomalies.reduce((sum, a) => sum + severityWeights[a.severity], 0) /
    detectedAnomalies.length;

  const anomalyScore = Math.min(
    100,
    Math.floor(avgSeverity + Math.random() * 15 - 7.5)
  );

  return {
    anomalyScore,
    detectedAnomalies,
    processedImageUrl: imageUrl,
  };
};

export const drawAnnotations = (
  canvas: HTMLCanvasElement,
  image: HTMLImageElement,
  anomalies: DetectedAnomaly[]
): void => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  canvas.width = image.width;
  canvas.height = image.height;

  ctx.drawImage(image, 0, 0);

  const severityColors = {
    low: '#10B981',
    medium: '#F59E0B',
    high: '#F97316',
    critical: '#DC2626',
  };

  anomalies.forEach((anomaly) => {
    const x = (anomaly.boundingBox.x / 100) * canvas.width;
    const y = (anomaly.boundingBox.y / 100) * canvas.height;
    const width = (anomaly.boundingBox.width / 100) * canvas.width;
    const height = (anomaly.boundingBox.height / 100) * canvas.height;

    const color = severityColors[anomaly.severity];

    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.strokeRect(x, y, width, height);

    ctx.fillStyle = color;
    ctx.globalAlpha = 0.2;
    ctx.fillRect(x, y, width, height);
    ctx.globalAlpha = 1;

    ctx.fillStyle = color;
    ctx.fillRect(x, y - 25, width, 25);

    ctx.fillStyle = 'white';
    ctx.font = 'bold 12px sans-serif';
    ctx.fillText(`${anomaly.type} (${anomaly.confidence}%)`, x + 5, y - 8);
  });
};
