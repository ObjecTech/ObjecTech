export const Logo = () => {
  return (
    <svg viewBox="0 0 400 120" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto">
      <defs>
        <linearGradient id="techGradient" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" style={{ stopColor: '#00d4ff', stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: '#0066ff', stopOpacity: 1 }} />
        </linearGradient>
        
        <pattern id="scanlines" x="0" y="0" width="4" height="4" patternUnits="userSpaceOnUse">
          <line x1="0" y1="0" x2="0" y2="4" stroke="#00d4ff" strokeWidth="0.5" opacity="0.3"/>
        </pattern>
      </defs>
      
      {/* 背景装饰 - 异常检测网格 */}
      <g opacity="0.15">
        <circle cx="35" cy="60" r="25" fill="none" stroke="url(#techGradient)" strokeWidth="1"/>
        <circle cx="35" cy="60" r="15" fill="none" stroke="url(#techGradient)" strokeWidth="1"/>
        <line x1="20" y1="60" x2="50" y2="60" stroke="url(#techGradient)" strokeWidth="1"/>
        <line x1="35" y1="45" x2="35" y2="75" stroke="url(#techGradient)" strokeWidth="1"/>
      </g>
      
      {/* 图标部分 - 异常检测符号 */}
      <g transform="translate(30, 60)">
        {/* 外围扫描圈 */}
        <circle cx="0" cy="0" r="22" fill="none" stroke="url(#techGradient)" strokeWidth="2.5" strokeDasharray="4,3">
          <animateTransform
            attributeName="transform"
            type="rotate"
            from="0 0 0"
            to="360 0 0"
            dur="8s"
            repeatCount="indefinite"/>
        </circle>
        
        {/* 中心六边形 - 代表对象识别 */}
        <path d="M 0,-12 L 10.4,-6 L 10.4,6 L 0,12 L -10.4,6 L -10.4,-6 Z" 
              fill="url(#techGradient)" opacity="0.9"/>
        
        {/* 异常标识点 */}
        <circle cx="0" cy="0" r="3" fill="#ffffff">
          <animate attributeName="r" values="3;4.5;3" dur="2s" repeatCount="indefinite"/>
        </circle>
        
        {/* 扫描雷达线 */}
        <line x1="0" y1="0" x2="0" y2="-20" stroke="#00d4ff" strokeWidth="2" opacity="0.8">
          <animateTransform
            attributeName="transform"
            type="rotate"
            from="0 0 0"
            to="360 0 0"
            dur="3s"
            repeatCount="indefinite"/>
        </line>
      </g>
      
      {/* 文字部分 */}
      <g transform="translate(75, 60)">
        {/* Objec 部分 - 常规字重 */}
        <text x="0" y="10" fontFamily="'Arial', 'Helvetica', sans-serif" fontSize="38" fontWeight="300" fill="#ffffff" letterSpacing="-1">
          Objec
        </text>
        
        {/* Tech 部分 - 加粗并使用渐变 */}
        <text x="98" y="10" fontFamily="'Arial', 'Helvetica', sans-serif" fontSize="38" fontWeight="700" fill="url(#techGradient)" letterSpacing="-1">
          Tech
        </text>
        
        {/* 下划线装饰 - 只在Tech下方 */}
        <line x1="98" y1="16" x2="183" y2="16" stroke="url(#techGradient)" strokeWidth="2.5" opacity="0.8"/>
        
        {/* 标语 */}
        <text x="0" y="32" fontFamily="'Arial', 'Helvetica', sans-serif" fontSize="10" fontWeight="400" fill="#999999" letterSpacing="2">
          ANOMALY DETECTION
        </text>
      </g>
      
      {/* 装饰性数据流 */}
      <g opacity="0.3">
        <rect x="280" y="45" width="2" height="8" fill="url(#techGradient)">
          <animate attributeName="height" values="8;15;8" dur="1.5s" repeatCount="indefinite"/>
        </rect>
        <rect x="290" y="40" width="2" height="12" fill="url(#techGradient)">
          <animate attributeName="height" values="12;20;12" dur="2s" repeatCount="indefinite"/>
        </rect>
        <rect x="300" y="48" width="2" height="6" fill="url(#techGradient)">
          <animate attributeName="height" values="6;18;6" dur="1.8s" repeatCount="indefinite"/>
        </rect>
      </g>
    </svg>
  );
};
