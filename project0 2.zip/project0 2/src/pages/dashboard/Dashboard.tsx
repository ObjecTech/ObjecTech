import { useState, useRef } from 'react';
import { Upload, X, Play, Save, ZoomIn, ZoomOut } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { useToast } from '../../components/ui/Toast';
import { Client } from '@gradio/client';

const ABSOLUTE_URL_PATTERN = /^(?:https?:|data:)/i;

const toAbsoluteUrl = (value: string, baseUrl?: string) => {
  if (!value) return '';
  if (ABSOLUTE_URL_PATTERN.test(value)) return value;
  if (!baseUrl) return value;

  try {
    return new URL(value, baseUrl).toString();
  } catch {
    const sanitizedBase = baseUrl.endsWith('/') ? baseUrl : `${baseUrl}/`;
    const sanitizedValue = value.startsWith('/') ? value.slice(1) : value;
    return `${sanitizedBase}${sanitizedValue}`;
  }
};

const resolveImageUrl = (imageData: unknown, baseUrl?: string): string | null => {
  if (!imageData) return null;

  if (typeof imageData === 'string') {
    return toAbsoluteUrl(imageData, baseUrl);
  }

  if (Array.isArray(imageData)) {
    for (const item of imageData) {
      const resolved = resolveImageUrl(item, baseUrl);
      if (resolved) return resolved;
    }
    return null;
  }

  if (typeof imageData === 'object') {
    const record = imageData as Record<string, unknown>;
    const candidates = ['url', 'data', 'path', 'name'] as const;

    for (const key of candidates) {
      const value = record[key];
      if (typeof value === 'string' && value) {
        const resolved = resolveImageUrl(value, baseUrl);
        if (resolved) return resolved;
      }
    }
  }

  return null;
};

export const Dashboard = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [className, setClassName] = useState<string>('');
  const [pretrainedDataset, setPretrainedDataset] = useState<string>('MVTec AD+Colondb');
  const [isProcessing, setIsProcessing] = useState(false);
  const [outputImage, setOutputImage] = useState<string>('');
  const [anomalyScore, setAnomalyScore] = useState<string>('');
  const [zoom, setZoom] = useState(1);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const { showToast } = useToast();

  const DATASET_OPTIONS = ['MVTec AD+Colondb', 'VisA+Clinicdb', 'All'];

  const handleFileSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      showToast('error', 'Please select a valid image file');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      showToast('error', 'File size must be less than 10MB');
      return;
    }

    setSelectedFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
    setOutputImage('');
    setAnomalyScore('');
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileSelect(file);
  };

  const handleRunDetection = async () => {
    if (!selectedFile || !className.trim()) {
      showToast('error', 'Please upload an image and enter a class name');
      return;
    }

    setIsProcessing(true);

    try {
      // 连接到AdaCLIP API
      const client = await Client.connect("Caoyunkang/AdaCLIP");
      
      // 调用预测API
      const result = await client.predict("/predict", { 
        image: selectedFile,
        text: className.trim(),
        options: pretrainedDataset,
      });

      console.log('API Result:', result.data);

      // 解析返回的数据
      // result.data 是一个包含两个元素的数组：[outputImageRef, anomalyScore]
      const [imageRef, score] = result.data as [unknown, unknown];
      const baseUrl =
        client.config?.root_url ??
        client.config?.root ??
        (client.app_reference.startsWith('http')
          ? client.app_reference
          : `https://hf.space/embed/${client.app_reference}`);
      const resolvedImageUrl = resolveImageUrl(imageRef, baseUrl);
      const resolvedScore =
        typeof score === 'number'
          ? score.toString()
          : typeof score === 'string'
            ? score
            : '';

      if (!resolvedImageUrl) {
        throw new Error('Unable to resolve output image URL from API response.');
      }

      if (!resolvedScore) {
        throw new Error('API did not return a valid anomaly score.');
      }
      
      setOutputImage(resolvedImageUrl);
      setAnomalyScore(resolvedScore);

      showToast('success', 'Detection completed successfully!');
    } catch (error) {
      showToast('error', 'Failed to run detection. Please try again.');
      console.error('Detection error:', error);
    } finally {
      setIsProcessing(false);
    }
  };



  const handleSaveDetection = () => {
    if (!outputImage || !anomalyScore || !imagePreview) return;

    try {
      const score = parseFloat(anomalyScore);
      // 分数越低越异常,低于 0.9 为高风险
      const severityLevel = score < 0.9 ? 'high' : score < 0.95 ? 'medium' : 'low';

      // 创建检测记录
      const detection = {
        id: Date.now().toString(),
        image_url: imagePreview, // 使用本地预览图片
        output_url: outputImage,
        keywords: [className],
        detection_results: [{
          type: className,
          description: `Anomaly detection using ${pretrainedDataset}`,
          severity: severityLevel,
          confidence: score,
        }],
        anomaly_score: score,
        severity_level: severityLevel,
        dataset: pretrainedDataset,
        created_at: new Date().toISOString(),
      };

      // 从 localStorage 读取现有记录
      const existingData = localStorage.getItem('detectionHistory');
      const history = existingData ? JSON.parse(existingData) : [];
      
      // 添加新记录到开头
      history.unshift(detection);
      
      // 只保留最近100条记录
      const limitedHistory = history.slice(0, 100);
      
      // 保存到 localStorage
      localStorage.setItem('detectionHistory', JSON.stringify(limitedHistory));

      showToast('success', 'Detection saved to history!');
    } catch (error) {
      showToast('error', 'Failed to save detection');
      console.error(error);
    }
  };

  const handleNewDetection = () => {
    setSelectedFile(null);
    setImagePreview('');
    setClassName('');
    setOutputImage('');
    setAnomalyScore('');
    setZoom(1);
  };

  const getSeverityColor = (score: string) => {
    const numScore = parseFloat(score);
    // 分数越低越异常,低于 0.9 为高风险
    if (numScore < 0.9) return 'text-red-600';
    if (numScore < 0.95) return 'text-orange-600';
    return 'text-green-600';
  };

  const getSeverityBg = (score: string) => {
    const numScore = parseFloat(score);
    // 分数越低越异常,低于 0.9 为高风险
    if (numScore < 0.9) return 'bg-red-100';
    if (numScore < 0.95) return 'bg-orange-100';
    return 'bg-green-100';
  };

  const getSeverityLabel = (score: string) => {
    const numScore = parseFloat(score);
    // 分数越低越异常,低于 0.9 为高风险
    if (numScore < 0.9) return 'High Risk';
    if (numScore < 0.95) return 'Medium Risk';
    return 'Low Risk';
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">ObjecTech Anomaly Detection</h1>
          <p className="text-sm sm:text-base text-gray-600 mt-2">Upload an image and specify class name to detect anomalies using ObjecTech</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Upload Image</h2>

              {!imagePreview ? (
                <div
                  onDrop={handleDrop}
                  onDragOver={(e) => e.preventDefault()}
                  onClick={() => fileInputRef.current?.click()}
                  className="border-3 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-blue-500 hover:bg-blue-50 transition-all duration-300 cursor-pointer"
                >
                  <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-lg font-medium text-gray-700 mb-2">
                    Drag & Drop or Click to Upload
                  </p>
                  <p className="text-sm text-gray-500">JPG, PNG, WebP up to 10MB</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileInput}
                    className="hidden"
                  />
                </div>
              ) : (
                <div className="relative">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="w-full rounded-lg"
                    style={{ transform: `scale(${zoom})`, transformOrigin: 'top left' }}
                  />
                  <div className="absolute top-2 right-2 flex gap-2">
                    <button
                      onClick={() => setZoom(Math.min(2, zoom + 0.2))}
                      className="p-2 bg-white rounded-lg shadow-lg hover:bg-gray-100"
                    >
                      <ZoomIn className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => setZoom(Math.max(0.5, zoom - 0.2))}
                      className="p-2 bg-white rounded-lg shadow-lg hover:bg-gray-100"
                    >
                      <ZoomOut className="w-5 h-5" />
                    </button>
                    <button
                      onClick={handleNewDetection}
                      className="p-2 bg-white rounded-lg shadow-lg hover:bg-gray-100"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  {selectedFile && (
                    <p className="mt-2 text-sm text-gray-600">
                      {selectedFile.name} ({Math.round(selectedFile.size / 1024)} KB)
                    </p>
                  )}
                </div>
              )}
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Detection Parameters</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Class Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={className}
                    onChange={(e) => setClassName(e.target.value)}
                    placeholder="e.g., bottle, cable, capsule"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Enter the object class to detect anomalies
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Pre-trained Datasets
                  </label>
                  <div className="space-y-2">
                    {DATASET_OPTIONS.map((option) => (
                      <label key={option} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="dataset"
                          value={option}
                          checked={pretrainedDataset === option}
                          onChange={(e) => setPretrainedDataset(e.target.value)}
                          className="w-4 h-4 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-sm text-gray-700">{option}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <Button
                onClick={handleRunDetection}
                variant="primary"
                size="lg"
                isLoading={isProcessing}
                disabled={!selectedFile || !className.trim()}
                className="w-full mt-6 flex items-center justify-center gap-2"
              >
                <Play className="w-5 h-5" />
                {isProcessing ? 'Processing...' : 'Run Detection'}
              </Button>
            </div>
          </div>

          <div className="space-y-6">
            {outputImage && anomalyScore ? (
              <>
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h2 className="text-xl font-bold text-gray-900 mb-4">Detection Results</h2>

                  <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full ${getSeverityBg(anomalyScore)} mx-auto mb-6`}>
                    <div className="text-center">
                      <div className={`text-4xl font-bold ${getSeverityColor(anomalyScore)}`}>
                        {parseFloat(anomalyScore).toFixed(2)}
                      </div>
                      <div className="text-sm font-medium text-gray-600">Anomaly Score</div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <h3 className="font-bold text-gray-900 mb-2">Output Image</h3>
                    <div className="relative">
                      <img
                        src={outputImage}
                        alt="Detection Result"
                        className="w-full rounded-lg border border-gray-200"
                      />
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-4 mb-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Class Name</p>
                        <p className="font-medium text-gray-900">{className}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Dataset</p>
                        <p className="font-medium text-gray-900">{pretrainedDataset}</p>
                      </div>
                      <div className="col-span-2">
                        <p className="text-sm text-gray-600">Anomaly Score</p>
                        <p className={`font-bold ${getSeverityColor(anomalyScore)}`}>
                          {parseFloat(anomalyScore).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <Button onClick={handleSaveDetection} variant="success" className="flex items-center justify-center gap-2">
                      <Save className="w-4 h-4" />
                      Save
                    </Button>
                    <Button onClick={handleNewDetection} variant="secondary" className="flex items-center justify-center gap-2">
                      <Play className="w-4 h-4" />
                      New Detection
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <div className="bg-white rounded-xl shadow-lg p-12 text-center">
                <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Play className="w-12 h-12 text-gray-400" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">No Results Yet</h3>
                <p className="text-gray-600">
                  Upload an image and enter class name to run your first detection
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
