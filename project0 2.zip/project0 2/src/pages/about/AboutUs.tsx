import { Users, Target, CheckCircle, Mail, Heart, Lightbulb } from 'lucide-react';

export const AboutUs = () => {
  const teamMembers = [
    { name: 'Frontend Dev', role: 'UI/UX Implementation', icon: '💻' },
    { name: 'Backend Dev', role: 'Server & Database', icon: '⚙️' },
    { name: 'UI/UX Designer', role: 'Interface Design', icon: '🎨' },
    { name: 'QA Engineer', role: 'Quality Assurance', icon: '🔍' },
    { name: 'Project Manager', role: 'Team Coordination', icon: '📋' },
    { name: 'AI Specialist', role: 'ML Integration', icon: '🤖' },
    { name: 'DevOps', role: 'Deployment & Ops', icon: '🚀' },
  ];

  const features = [
    {
      icon: CheckCircle,
      title: 'Image Upload Function',
      description: 'Easily upload anomaly images, with the system providing instant detection results to help you quickly identify equipment failures or safety hazards.',
      color: 'blue',
    },
    {
      icon: Target,
      title: 'Historical Records Function',
      description: 'View all upload records, supporting selective deletion for convenient management and review of past data.',
      color: 'orange',
    },
    {
      icon: Users,
      title: 'Personal Center Function',
      description: 'Customize preference settings, such as notification preferences, to create a personalized user experience.',
      color: 'green',
    },
  ];

  return (
    <div className="p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About ObjecTech</h1>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-blue-400 mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Building intelligent anomaly detection solutions for a safer future
          </p>
        </div>

        {/* Project Overview Section */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-12">
          <div className="flex items-center gap-3 mb-6">
            <Lightbulb className="w-8 h-8 text-blue-700" />
            <h2 className="text-3xl font-bold text-gray-900">Our Project Overview</h2>
          </div>
          <p className="text-lg text-gray-700 leading-relaxed">
            ObjecTech is an efficient anomaly detection web management system, designed specifically for users, 
            helping you easily upload images, identify anomalies in real-time, view historical records, and 
            optimize personal image resource management. It assists you in discovering potential issues in advance, 
            improving work efficiency and safety.
          </p>
        </div>

        {/* Pre-trained Datasets Section */}
        <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl shadow-lg p-8 mb-12">
          <div className="flex items-center gap-3 mb-6">
            <Target className="w-8 h-8 text-blue-700" />
            <h2 className="text-3xl font-bold text-gray-900">Pre-trained Datasets</h2>
          </div>
          <p className="text-lg text-gray-700 mb-6 leading-relaxed">
            In ObjecTech, we offer flexible pre-trained dataset options to support our anomaly detection models, 
            allowing users to choose the dataset that best fits their specific needs. These options are built on 
            different dataset combinations, and users can select according to the characteristics of their own tasks:
          </p>
          
          <div className="space-y-6">
            <div className="bg-white rounded-xl p-6 shadow-md border-l-4 border-blue-500">
              <h3 className="text-xl font-bold text-gray-900 mb-3">MVTec AD + ColonDB</h3>
              <p className="text-gray-700 leading-relaxed">
                Trained on both the industrial anomaly detection dataset (MVTec AD) and the medical endoscopy dataset (ColonDB), 
                this version enables the model to remain highly sensitive to subtle defects.
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-md border-l-4 border-green-500">
              <h3 className="text-xl font-bold text-gray-900 mb-3">VisA + ClinicDB</h3>
              <p className="text-gray-700 leading-relaxed">
                Pre-trained using VisA (a multi-category visual anomaly dataset) and ClinicDB (a clinical imaging dataset), 
                this option enhances model stability across varying lighting conditions, devices, and backgrounds.
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-md border-l-4 border-purple-500">
              <h3 className="text-xl font-bold text-gray-900 mb-3">All</h3>
              <p className="text-gray-700 leading-relaxed">
                This comprehensive option integrates all of the above datasets to provide a general-purpose model 
                that benefits from multiple data sources.
              </p>
            </div>
          </div>
          
          <p className="text-lg text-gray-700 mt-8 leading-relaxed">
            These pre-trained dataset configurations ensure that our platform delivers reliable, data-driven results 
            tailored to your workflow. If you are working with a specific type of imagery, we recommend trying each 
            option to find the best match!
          </p>
        </div>

        {/* Team Members Section */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl shadow-lg p-8 mb-12">
          <div className="flex items-center gap-3 mb-6">
            <Users className="w-8 h-8 text-blue-700" />
            <h2 className="text-3xl font-bold text-gray-900">Team Members</h2>
          </div>
          <p className="text-lg text-gray-700 mb-8 leading-relaxed">
            Our team consists of seven members, covering areas such as front-end development, back-end logic, 
            UI/UX design, and system testing. During the project development process, we collaborated closely, 
            jointly overcoming technical challenges to ensure the system's stability and reliability. We are 
            committed to transforming innovative ideas into practical tools.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {teamMembers.map((member, index) => (
              <div 
                key={index}
                className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all duration-300 hover:scale-105"
              >
                <div className="text-4xl mb-3 text-center">{member.icon}</div>
                <h3 className="font-bold text-gray-900 text-center mb-1">{member.name}</h3>
                <p className="text-sm text-gray-600 text-center">{member.role}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Core Functions Section */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-12">
          <div className="flex items-center gap-3 mb-8">
            <Target className="w-8 h-8 text-blue-700" />
            <h2 className="text-3xl font-bold text-gray-900">Core Functions</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              const colorClasses = {
                blue: 'bg-blue-100 text-blue-700',
                orange: 'bg-orange-100 text-orange-700',
                green: 'bg-green-100 text-green-700',
              }[feature.color];

              return (
                <div 
                  key={index}
                  className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-all duration-300"
                >
                  <div className={`w-14 h-14 rounded-lg ${colorClasses} flex items-center justify-center mb-4`}>
                    <Icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Vision Section */}
        <div className="bg-gradient-to-r from-blue-700 to-indigo-700 rounded-2xl shadow-lg p-8 text-white mb-12">
          <h2 className="text-3xl font-bold mb-4">Our Vision</h2>
          <p className="text-lg leading-relaxed mb-6">
            Our current version is still in the testing phase, and we will continue to develop full features in the future. 
            We are committed to continuously iterating ObjecTech to make it more intelligent and user-friendly, 
            for example, by integrating AI-enhanced analysis and multi-platform support. Your feedback is the 
            driving force behind our progress—welcome to submit suggestions through the form below or via email 
            <a href="mailto:1426863016@qq.com" className="underline ml-1 hover:text-blue-200">
              (1426863016@qq.com)
            </a>, and let's build a better system together!
          </p>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
            <div className="flex items-center gap-2 mb-3">
              <Mail className="w-5 h-5" />
              <h3 className="font-bold text-lg">Contact Us</h3>
            </div>
            <p className="text-white/90">
              Email: <a href="mailto:1426863016@qq.com" className="underline hover:text-blue-200">1426863016@qq.com</a>
            </p>
          </div>
        </div>

        {/* Acknowledgments Section */}
        <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Heart className="w-8 h-8 text-red-500 fill-red-500" />
            <h2 className="text-3xl font-bold text-gray-900">Acknowledgments</h2>
          </div>
          <p className="text-lg text-gray-700 leading-relaxed max-w-3xl mx-auto">
            Thank you to all participants and supporters! Your trust is our greatest motivation. 
            If you have any questions, feel free to contact us at any time.
          </p>
        </div>
      </div>
    </div>
  );
};
