import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Image as ImageIcon, AlertTriangle, Calendar, Clock, Trash2 } from 'lucide-react';
import { useToast } from '../../components/ui/Toast';

interface Detection {
  id: string;
  image_url: string;
  keywords: string[];
  anomaly_score: number;
  severity_level: string;
  created_at: string;
}

interface StatsData {
  totalDetections: number;
  anomalyRate: number;
  weeklyChange: number;
  anomalyTypeCounts: Record<string, number>;
  detectionsByDate: Array<{ date: string; count: number }>;
}

export const Statistics = () => {
  const [dateRange, setDateRange] = useState(30);
  const [stats, setStats] = useState<StatsData>({
    totalDetections: 0,
    anomalyRate: 0,
    weeklyChange: 0,
    anomalyTypeCounts: {},
    detectionsByDate: [],
  });
  const [isLoading, setIsLoading] = useState(false);
  const [detectionHistory, setDetectionHistory] = useState<Detection[]>([]);
  const { showToast } = useToast();

  useEffect(() => {
    loadDetectionHistory();
    loadFullHistory();
  }, [dateRange]);

  const loadFullHistory = () => {
    try {
      const historyData = localStorage.getItem('detectionHistory');
      if (historyData) {
        const allDetections = JSON.parse(historyData);
        setDetectionHistory(allDetections);
      }
    } catch (error) {
      console.error('Error loading full history:', error);
    }
  };

  const loadDetectionHistory = () => {
    try {
      // 从 localStorage 读取检测历史
      const historyData = localStorage.getItem('detectionHistory');
      if (!historyData) {
        setStats({
          totalDetections: 0,
          anomalyRate: 0,
          weeklyChange: 0,
          anomalyTypeCounts: {},
          detectionsByDate: [],
        });
        return;
      }

      const allDetections = JSON.parse(historyData);
      
      // 根据日期范围过滤
      const endDate = new Date();
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - dateRange);

      const detections = allDetections.filter((d: any) => {
        const detectionDate = new Date(d.created_at);
        return detectionDate >= startDate && detectionDate <= endDate;
      });

      if (detections.length === 0) {
        setStats({
          totalDetections: 0,
          anomalyRate: 0,
          weeklyChange: 0,
          anomalyTypeCounts: {},
          detectionsByDate: [],
        });
        return;
      }

      // 计算统计数据
      const totalDetections = detections.length;
      const avgScore = detections.reduce((sum: number, d: any) => sum + d.anomaly_score, 0) / totalDetections;

      // 计算周变化
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      const recentDetections = detections.filter(
        (d: any) => new Date(d.created_at) >= weekAgo
      ).length;
      const olderDetections = totalDetections - recentDetections;
      const weeklyChange = olderDetections > 0 
        ? Math.round(((recentDetections - olderDetections) / olderDetections) * 100)
        : 0;

      // 统计异常类型
      const typeCounts: Record<string, number> = {};
      detections.forEach((detection: any) => {
        if (detection.keywords && Array.isArray(detection.keywords)) {
          detection.keywords.forEach((keyword: string) => {
            typeCounts[keyword] = (typeCounts[keyword] || 0) + 1;
          });
        }
      });

      // 按日期统计
      const dateCountsMap: Record<string, number> = {};
      detections.forEach((detection: any) => {
        const date = new Date(detection.created_at).toISOString().split('T')[0];
        dateCountsMap[date] = (dateCountsMap[date] || 0) + 1;
      });

      const detectionsByDate = Object.entries(dateCountsMap)
        .map(([date, count]) => ({ date, count }))
        .sort((a, b) => a.date.localeCompare(b.date));

      setStats({
        totalDetections,
        anomalyRate: Math.round(avgScore),
        weeklyChange,
        anomalyTypeCounts: typeCounts,
        detectionsByDate,
      });
    } catch (error) {
      console.error('Error loading detection history:', error);
      setStats({
        totalDetections: 0,
        anomalyRate: 0,
        weeklyChange: 0,
        anomalyTypeCounts: {},
        detectionsByDate: [],
      });
    }
  };

  const getTopAnomalies = () => {
    return Object.entries(stats.anomalyTypeCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5);
  };

  const getAnomalyColors = () => {
    const colors = ['#1E40AF', '#F97316', '#10B981', '#F59E0B', '#DC2626', '#6B7280'];
    return colors;
  };

  const deleteDetection = (id: string) => {
    try {
      const historyData = localStorage.getItem('detectionHistory');
      if (historyData) {
        const allDetections = JSON.parse(historyData);
        const updatedDetections = allDetections.filter((d: any) => d.id !== id);
        localStorage.setItem('detectionHistory', JSON.stringify(updatedDetections));
        
        setDetectionHistory(updatedDetections);
        loadDetectionHistory(); // 重新加载统计数据
        showToast('success', 'Detection deleted');
      }
    } catch (error) {
      showToast('error', 'Failed to delete detection');
    }
  };

  const getSeverityColor = (level: string) => {
    switch (level) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-green-100 text-green-800';
    }
  };

  if (isLoading) {
    return (
      <div className="p-8 flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin w-16 h-16 border-4 border-blue-700 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading statistics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Statistics & Analytics</h1>
            <p className="text-gray-600 mt-2">Track detection trends and analyze patterns</p>
          </div>

          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-gray-500" />
            <select
              value={dateRange}
              onChange={(e) => setDateRange(Number(e.target.value))}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value={7}>Last 7 Days</option>
              <option value={30}>Last 30 Days</option>
              <option value={90}>Last 90 Days</option>
            </select>
          </div>
        </div>

        {stats.totalDetections === 0 ? (
          <div className="bg-white rounded-xl shadow-lg p-12 text-center">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <ImageIcon className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">No Data Yet</h3>
            <p className="text-gray-600">
              Run your first detection to see analytics and trends
            </p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-600">Total Images Analyzed</span>
                  <ImageIcon className="w-5 h-5 text-blue-700" />
                </div>
                <div className="text-3xl font-bold text-gray-900">{stats.totalDetections}</div>
                <div className="mt-2 flex items-center text-sm">
                  <span className="text-gray-500">in last {dateRange} days</span>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-600">Anomaly Rate</span>
                  <AlertTriangle className="w-5 h-5 text-orange-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900">{stats.anomalyRate}%</div>
                <div className="mt-2 flex items-center text-sm">
                  <span className={`font-medium ${
                    stats.anomalyRate >= 70 ? 'text-red-600' :
                    stats.anomalyRate >= 40 ? 'text-orange-600' :
                    'text-green-600'
                  }`}>
                    {stats.anomalyRate >= 70 ? 'High' : stats.anomalyRate >= 40 ? 'Medium' : 'Low'} severity
                  </span>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-600">Weekly Activity</span>
                  {stats.weeklyChange >= 0 ? (
                    <TrendingUp className="w-5 h-5 text-green-600" />
                  ) : (
                    <TrendingDown className="w-5 h-5 text-red-600" />
                  )}
                </div>
                <div className="text-3xl font-bold text-gray-900">{stats.weeklyChange}%</div>
                <div className="mt-2 flex items-center text-sm">
                  <span className={`font-medium ${stats.weeklyChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {stats.weeklyChange >= 0 ? '↑' : '↓'} vs. previous period
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Anomaly Type Distribution</h2>
                {getTopAnomalies().length > 0 ? (
                  <div className="space-y-4">
                    {getTopAnomalies().map(([type, count], index) => {
                      const percentage = Math.round((count / stats.totalDetections) * 100);
                      const colors = getAnomalyColors();
                      return (
                        <div key={type}>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium text-gray-700">{type}</span>
                            <span className="text-sm font-bold text-gray-900">{count} ({percentage}%)</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-3">
                            <div
                              className="h-3 rounded-full transition-all duration-500"
                              style={{
                                width: `${percentage}%`,
                                backgroundColor: colors[index % colors.length],
                              }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-8">No anomaly data available</p>
                )}
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Detection Timeline</h2>
                {stats.detectionsByDate.length > 0 ? (
                  <div className="space-y-3">
                    {stats.detectionsByDate.slice(-10).reverse().map((item) => (
                      <div key={item.date} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-700">
                          {new Date(item.date).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric',
                          })}
                        </span>
                        <span className="text-sm font-bold text-blue-700">{item.count} detections</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-8">No timeline data available</p>
                )}
              </div>
            </div>

            {/* Detection History Section */}
            <div className="bg-white rounded-xl shadow-lg p-6 mt-8">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Detection History</h2>
              {detectionHistory.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No detections yet. Upload an image from the Dashboard to start detecting anomalies.</p>
              ) : (
                <div className="space-y-3">
                  {detectionHistory.map((detection) => (
                    <div key={detection.id} className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                      <img
                        src={detection.image_url}
                        alt="Detection"
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Clock className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-600">
                            {new Date(detection.created_at).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-2 mb-2">
                          {detection.keywords.slice(0, 3).map((keyword) => (
                            <span key={keyword} className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded">
                              {keyword}
                            </span>
                          ))}
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-bold text-gray-900">
                            Score: {detection.anomaly_score.toFixed(2)}
                          </span>
                          <span className={`px-2 py-1 text-xs font-medium rounded ${getSeverityColor(detection.severity_level)}`}>
                            {detection.severity_level.toUpperCase()}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => deleteDetection(detection.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
