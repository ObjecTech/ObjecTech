import { useState } from 'react';
import { User, Building, Briefcase, Mail, Lock, Trash2, Save, Edit2 } from 'lucide-react';
import { useToast } from '../../components/ui/Toast';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';

export const Profile = () => {
  const { showToast } = useToast();

  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    full_name: 'Guest User',
    company_name: 'Demo Company',
    role: 'Engineer',
    email: 'demo@objectech.com',
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const [preferences, setPreferences] = useState({
    email_high_severity: true,
    email_weekly_summary: false,
    email_security_alerts: true,
  });

  const [showPasswordModal, setShowPasswordModal] = useState(false);

  const roles = ['Engineer', 'Manager', 'Quality Control', 'Safety Officer', 'Administrator', 'Other'];

  const handleSaveProfile = () => {
    showToast('success', 'Profile updated successfully!');
    setIsEditing(false);
  };

  const handlePasswordChange = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      showToast('error', 'Passwords do not match');
      return;
    }

    if (passwordData.newPassword.length < 8) {
      showToast('error', 'Password must be at least 8 characters');
      return;
    }

    showToast('success', 'Password updated successfully!');
    setShowPasswordModal(false);
    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  const handleDeleteAccount = () => {
    if (!window.confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      return;
    }

    showToast('error', 'Account deletion is not available in this demo');
  };

  return (
    <div className="p-8">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Profile & Settings</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6 text-center">
            <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-12 h-12 text-blue-700" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">{formData.full_name}</h2>
            <p className="text-gray-600 mt-1">{formData.company_name}</p>
            <p className="text-sm text-gray-500 mt-2">{formData.role}</p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="font-bold text-gray-900 mb-4">Usage Statistics</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Total Detections</span>
                <span className="font-bold text-gray-900">-</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Account Active Since</span>
                <span className="font-bold text-gray-900">Nov 2024</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Last Login</span>
                <span className="font-bold text-gray-900">Today</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Profile Information</h2>
            {!isEditing ? (
              <Button onClick={() => setIsEditing(true)} variant="secondary" size="sm" className="flex items-center gap-2">
                <Edit2 className="w-4 h-4" />
                Edit Profile
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button onClick={() => setIsEditing(false)} variant="secondary" size="sm">
                  Cancel
                </Button>
                <Button onClick={handleSaveProfile} variant="primary" size="sm" className="flex items-center gap-2">
                  <Save className="w-4 h-4" />
                  Save Changes
                </Button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input
              label="Full Name"
              value={formData.full_name}
              onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
              disabled={!isEditing}
              icon={<User className="w-5 h-5 text-gray-400" />}
            />

            <Input
              label="Email"
              value={formData.email}
              disabled
              icon={<Mail className="w-5 h-5 text-gray-400" />}
            />

            <Input
              label="Company Name"
              value={formData.company_name}
              onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
              disabled={!isEditing}
              icon={<Building className="w-5 h-5 text-gray-400" />}
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
              <div className="relative">
                <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
                <select
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  disabled={!isEditing}
                  className="block w-full rounded-lg border border-gray-300 pl-10 pr-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100"
                >
                  {roles.map((role) => (
                    <option key={role} value={role}>
                      {role}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Notification Preferences</h2>
          <div className="space-y-4">
            <label className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
              <div>
                <div className="font-medium text-gray-900">High Severity Alerts</div>
                <div className="text-sm text-gray-600">Receive email notifications for critical detections</div>
              </div>
              <input
                type="checkbox"
                checked={preferences.email_high_severity}
                onChange={(e) => {
                  const newPrefs = { ...preferences, email_high_severity: e.target.checked };
                  setPreferences(newPrefs);
                }}
                className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500"
              />
            </label>

            <label className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
              <div>
                <div className="font-medium text-gray-900">Weekly Summary Report</div>
                <div className="text-sm text-gray-600">Get a weekly email with detection analytics</div>
              </div>
              <input
                type="checkbox"
                checked={preferences.email_weekly_summary}
                onChange={(e) => {
                  const newPrefs = { ...preferences, email_weekly_summary: e.target.checked };
                  setPreferences(newPrefs);
                }}
                className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500"
              />
            </label>

            <label className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
              <div>
                <div className="font-medium text-gray-900">Account Security Alerts</div>
                <div className="text-sm text-gray-600">Notifications about login activity and security</div>
              </div>
              <input
                type="checkbox"
                checked={preferences.email_security_alerts}
                onChange={(e) => {
                  const newPrefs = { ...preferences, email_security_alerts: e.target.checked };
                  setPreferences(newPrefs);
                }}
                className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500"
              />
            </label>
          </div>
        </div>

        {showPasswordModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Change Password</h2>
              <div className="space-y-4 mb-6">
                <Input
                  type="password"
                  label="New Password"
                  placeholder="Min. 8 characters"
                  value={passwordData.newPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                  icon={<Lock className="w-5 h-5 text-gray-400" />}
                />
                <Input
                  type="password"
                  label="Confirm Password"
                  placeholder="Re-enter password"
                  value={passwordData.confirmPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                  icon={<Lock className="w-5 h-5 text-gray-400" />}
                />
              </div>
              <div className="flex gap-3">
                <Button onClick={() => setShowPasswordModal(false)} variant="secondary" className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handlePasswordChange} variant="primary" className="flex-1">
                  Update Password
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
