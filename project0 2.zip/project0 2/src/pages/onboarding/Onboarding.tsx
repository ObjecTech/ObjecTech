import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Brain, TrendingDown, BarChart3, Wrench, PackageCheck, ShieldAlert, Upload, Tags, Eye, LineChart, ChevronRight, ChevronLeft } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { useToast } from '../../components/ui/Toast';

export const Onboarding = () => {
  const [currentPage, setCurrentPage] = useState(0);
  const navigate = useNavigate();
  const { showToast } = useToast();

  const handleSkip = () => {
    navigate('/dashboard');
  };

  const handleNext = () => {
    if (currentPage < 2) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handleBack = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleGetStarted = () => {
    showToast('success', 'Welcome to ObjecTech!');
    navigate('/dashboard');
  };

  const pages = [
    {
      title: 'Three Key Advantages',
      subtitle: 'Why factories trust ObjecTech',
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-transparent hover:border-blue-500 transition-all duration-300 hover:scale-105">
            <div className="w-14 h-14 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Brain className="w-8 h-8 text-blue-700" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">AI-Powered Detection</h3>
            <p className="text-gray-600">
              Advanced machine learning algorithms identify anomalies in real-time, catching issues before they become costly problems.
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-transparent hover:border-green-500 transition-all duration-300 hover:scale-105">
            <div className="w-14 h-14 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <TrendingDown className="w-8 h-8 text-green-700" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Cost Prevention</h3>
            <p className="text-gray-600">
              Early fault detection reduces downtime by up to 70%, saving thousands in maintenance and lost production time.
            </p>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-transparent hover:border-orange-500 transition-all duration-300 hover:scale-105">
            <div className="w-14 h-14 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
              <BarChart3 className="w-8 h-8 text-orange-700" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Comprehensive Analytics</h3>
            <p className="text-gray-600">
              Track trends, identify patterns, and make data-driven decisions with detailed statistics and visual reports.
            </p>
          </div>
        </div>
      ),
    },
    {
      title: 'What Can We Detect?',
      subtitle: 'Three main detection categories',
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6 shadow-lg border-2 border-blue-200 hover:shadow-xl transition-all duration-300">
            <div className="w-14 h-14 bg-blue-700 rounded-lg flex items-center justify-center mb-4">
              <Wrench className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Equipment Monitoring</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="text-blue-700 mr-2">•</span>
                Machine malfunctions
              </li>
              <li className="flex items-start">
                <span className="text-blue-700 mr-2">•</span>
                Tool wear and tear
              </li>
              <li className="flex items-start">
                <span className="text-blue-700 mr-2">•</span>
                Robotic positioning errors
              </li>
              <li className="flex items-start">
                <span className="text-blue-700 mr-2">•</span>
                Conveyor irregularities
              </li>
            </ul>
          </div>

          <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl p-6 shadow-lg border-2 border-orange-200 hover:shadow-xl transition-all duration-300">
            <div className="w-14 h-14 bg-orange-600 rounded-lg flex items-center justify-center mb-4">
              <PackageCheck className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Product Quality</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="text-orange-600 mr-2">•</span>
                Surface defects & cracks
              </li>
              <li className="flex items-start">
                <span className="text-orange-600 mr-2">•</span>
                Product deformation
              </li>
              <li className="flex items-start">
                <span className="text-orange-600 mr-2">•</span>
                Specification violations
              </li>
              <li className="flex items-start">
                <span className="text-orange-600 mr-2">•</span>
                Assembly line issues
              </li>
            </ul>
          </div>

          <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-xl p-6 shadow-lg border-2 border-red-200 hover:shadow-xl transition-all duration-300">
            <div className="w-14 h-14 bg-red-600 rounded-lg flex items-center justify-center mb-4">
              <ShieldAlert className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Safety Compliance</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="text-red-600 mr-2">•</span>
                Missing PPE violations
              </li>
              <li className="flex items-start">
                <span className="text-red-600 mr-2">•</span>
                Unsafe zone breaches
              </li>
              <li className="flex items-start">
                <span className="text-red-600 mr-2">•</span>
                Environmental hazards
              </li>
              <li className="flex items-start">
                <span className="text-red-600 mr-2">•</span>
                Gauge anomalies
              </li>
            </ul>
          </div>
        </div>
      ),
    },
    {
      title: 'How It Works',
      subtitle: 'Four simple steps to start detecting',
      content: (
        <div className="mt-8 max-w-3xl mx-auto">
          <div className="space-y-6">
            <div className="flex items-start gap-4 bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-12 h-12 bg-blue-700 rounded-full flex items-center justify-center flex-shrink-0 text-white font-bold text-lg">
                1
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <Upload className="w-6 h-6 text-blue-700" />
                  <h3 className="text-xl font-bold text-gray-900">Upload Image</h3>
                </div>
                <p className="text-gray-600">
                  Drag and drop or browse to upload factory floor images, equipment photos, or product snapshots.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0 text-white font-bold text-lg">
                2
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <Tags className="w-6 h-6 text-orange-600" />
                  <h3 className="text-xl font-bold text-gray-900">Add Detection Keywords</h3>
                </div>
                <p className="text-gray-600">
                  Specify what to look for: equipment malfunction, safety violation, product defect, or other anomaly types.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0 text-white font-bold text-lg">
                3
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <Eye className="w-6 h-6 text-green-600" />
                  <h3 className="text-xl font-bold text-gray-900">Review AI Results</h3>
                </div>
                <p className="text-gray-600">
                  Get instant analysis with annotated images, anomaly scores, confidence levels, and detailed breakdowns.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center flex-shrink-0 text-white font-bold text-lg">
                4
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <LineChart className="w-6 h-6 text-indigo-600" />
                  <h3 className="text-xl font-bold text-gray-900">Analyze Historical Trends</h3>
                </div>
                <p className="text-gray-600">
                  Track patterns over time, compare detection rates, and identify recurring issues with comprehensive analytics.
                </p>
              </div>
            </div>
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl">
        <div className="bg-gray-50 rounded-2xl shadow-2xl p-8 md:p-12">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-3">
              {pages[currentPage].title}
            </h1>
            <p className="text-xl text-gray-600">{pages[currentPage].subtitle}</p>
          </div>

          {pages[currentPage].content}

          <div className="flex items-center justify-between mt-12">
            <button
              onClick={handleSkip}
              className="text-gray-600 hover:text-gray-900 font-medium transition-colors"
            >
              Skip
            </button>

            <div className="flex gap-2">
              {pages.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentPage ? 'bg-blue-700 w-8' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>

            <div className="flex gap-3">
              {currentPage > 0 && (
                <Button
                  onClick={handleBack}
                  variant="secondary"
                  className="flex items-center gap-2"
                >
                  <ChevronLeft className="w-5 h-5" />
                  Back
                </Button>
              )}

              {currentPage < pages.length - 1 ? (
                <Button
                  onClick={handleNext}
                  variant="primary"
                  className="flex items-center gap-2"
                >
                  Next
                  <ChevronRight className="w-5 h-5" />
                </Button>
              ) : (
                <Button
                  onClick={handleGetStarted}
                  variant="primary"
                  size="lg"
                  className="flex items-center gap-2"
                >
                  Get Started
                  <ChevronRight className="w-5 h-5" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
