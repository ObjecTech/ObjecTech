/*
  # Create ObjecTech Factory Anomaly Detection Platform Schema

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key, references auth.users)
      - `full_name` (text)
      - `company_name` (text)
      - `role` (text)
      - `avatar_url` (text, nullable)
      - `preferences` (jsonb, stores notification settings, theme, etc.)
      - `onboarding_completed` (boolean, default false)
      - `created_at` (timestamptz)
      - `last_login` (timestamptz, nullable)
    
    - `anomaly_types`
      - `id` (uuid, primary key)
      - `category_name` (text, unique)
      - `description` (text)
      - `severity_level` (text)
      - `icon_name` (text)
      - `color_code` (text)
    
    - `detections`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `image_url` (text)
      - `keywords` (text array)
      - `detection_results` (jsonb, stores anomalies array)
      - `anomaly_score` (integer, 0-100)
      - `severity_level` (text)
      - `flagged` (boolean, default false)
      - `created_at` (timestamptz)
    
    - `detection_statistics`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `date` (date)
      - `total_detections` (integer, default 0)
      - `anomaly_counts` (jsonb, stores counts by type)
      - `average_score` (numeric)
      - `created_at` (timestamptz)
    
    - `notifications`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `type` (text)
      - `title` (text)
      - `message` (text)
      - `read` (boolean, default false)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read/write their own data
    - Add policies for anomaly_types table (public read access)

  3. Indexes
    - Add indexes on frequently queried columns for performance

  4. Initial Data
    - Populate anomaly_types table with predefined categories
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  company_name text NOT NULL,
  role text NOT NULL,
  avatar_url text,
  preferences jsonb DEFAULT '{"email_high_severity": true, "email_weekly_summary": false, "email_security_alerts": true, "theme": "light"}'::jsonb,
  onboarding_completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  last_login timestamptz
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create anomaly_types table
CREATE TABLE IF NOT EXISTS anomaly_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_name text UNIQUE NOT NULL,
  description text NOT NULL,
  severity_level text NOT NULL,
  icon_name text NOT NULL,
  color_code text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE anomaly_types ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anomaly types are publicly readable"
  ON anomaly_types FOR SELECT
  TO authenticated
  USING (true);

-- Create detections table
CREATE TABLE IF NOT EXISTS detections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  keywords text[] NOT NULL,
  detection_results jsonb DEFAULT '[]'::jsonb,
  anomaly_score integer NOT NULL DEFAULT 0,
  severity_level text NOT NULL DEFAULT 'low',
  flagged boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE detections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own detections"
  ON detections FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own detections"
  ON detections FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own detections"
  ON detections FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own detections"
  ON detections FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create detection_statistics table
CREATE TABLE IF NOT EXISTS detection_statistics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  date date NOT NULL,
  total_detections integer DEFAULT 0,
  anomaly_counts jsonb DEFAULT '{}'::jsonb,
  average_score numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, date)
);

ALTER TABLE detection_statistics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own statistics"
  ON detection_statistics FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own statistics"
  ON detection_statistics FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own statistics"
  ON detection_statistics FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own notifications"
  ON notifications FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_detections_user_id ON detections(user_id);
CREATE INDEX IF NOT EXISTS idx_detections_created_at ON detections(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_detection_statistics_user_date ON detection_statistics(user_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, read, created_at DESC);

-- Insert predefined anomaly types
INSERT INTO anomaly_types (category_name, description, severity_level, icon_name, color_code) VALUES
  ('Equipment Malfunction', 'Machinery or equipment showing signs of failure or improper operation', 'high', 'Wrench', '#DC2626'),
  ('Product Quality Defect', 'Surface defects, cracks, deformation, or non-compliance with specifications', 'high', 'AlertTriangle', '#F97316'),
  ('Safety Violation', 'Missing PPE, unsafe zones, or safety protocol breaches', 'critical', 'ShieldAlert', '#DC2626'),
  ('Assembly Line Issue', 'Misalignment, positioning errors, or workflow disruptions', 'medium', 'Workflow', '#F59E0B'),
  ('Inventory Error', 'Incorrect placement, missing items, or organization issues', 'low', 'Package', '#10B981'),
  ('Environmental Hazard', 'Leaks, spills, smoke, or environmental risks', 'critical', 'Droplet', '#DC2626'),
  ('Gauge Anomaly', 'Temperature, pressure, or other sensor readings outside normal range', 'medium', 'Gauge', '#F97316'),
  ('Robotic Issue', 'Robotic arm positioning errors or operational irregularities', 'medium', 'Bot', '#F59E0B'),
  ('Conveyor Problem', 'Belt irregularities, speed issues, or blockages', 'medium', 'MoveHorizontal', '#F97316'),
  ('General Anomaly', 'Other detected issues not fitting specific categories', 'low', 'AlertCircle', '#6B7280')
ON CONFLICT (category_name) DO NOTHING;