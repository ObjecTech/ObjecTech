/*
  # Create Supabase Storage Bucket for Detection Images

  1. Storage Setup
    - Create a public storage bucket named 'detection-images'
    - Set up bucket policies to allow authenticated users to upload images
    - Allow public read access to images (for viewing detection results)
    - Restrict delete operations to image owners only

  2. Security
    - Authenticated users can upload (INSERT) to their own folder
    - Anyone can read (SELECT) images for viewing results
    - Only owners can update/delete their images
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('detection-images', 'detection-images', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Authenticated users can upload detection images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'detection-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Anyone can view detection images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'detection-images');

CREATE POLICY "Users can update own detection images"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'detection-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'detection-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can delete own detection images"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'detection-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
);